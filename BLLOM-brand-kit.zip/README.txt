BLLOM brand kit

Icon = selected perspective mark by itself, useful for profile images and watermarks.
Logo = perspective mark with the BLLOM wordmark.

Transparent files have no background. Use black on light photos or pages and white on dark ones.
On-white and on-black files have a solid background and are ready to share or upload.
SVG files scale without losing quality. PNG icons are 1200 pixels wide; PNG logos are 2400 pixels wide.
Brand colors: charcoal #151515 and white #FFFFFF.
